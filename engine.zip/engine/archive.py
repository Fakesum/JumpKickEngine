#TODO: Use the JumpKickEngine.ml to get subreddits
active_subreddits: list = ["JumpkickEngine", "JumpkickEngine1"]